#%%
'''1.15 RESULTS: variables need to be declared first in order to use them
'''
C = A + B
A = 3
B = 2
print C