#%%
''' 1.18 ONLY FIND THE ERROR. RESULTS: variable tan needs to have a different
name. also print needs a parenthesis
'''
from math import pi, tan
tan1 = tan(pi/4)
tan2 = tan(pi/3)
print tan1, tan2