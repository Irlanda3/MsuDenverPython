#%%
'''1.16 RESULTS:3.141592653589793
-1.2246467991473532e-16
-2.6535897933620727e-06. a variable cannot start with a number
 and many other syntax errors. tan of pi must be a real number

'''
import cmath
import math
a2 = 2
a1 = b
x = 2
y = 4
y2 = x + y # is it 6?
from math import tan
var3 = math.pi
print(var3)
print (math.tan(var3))

pi = 3.14159
print (tan(pi))
c = 4**3**2**3
variable3 = ((c-78564)/c + 32)
discount = 12#%
AMOUNT = 120.#-
amount = 120#$
address = "hpl@simula.no"
variable_and = "duck"
classe = "INF1100, gr 2"
continue_ = x > 0
rev = fox = True
Norwegian = ["a human language"]
true = fox is rev in Norwegian